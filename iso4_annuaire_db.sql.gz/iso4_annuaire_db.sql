-- Adminer 4.7.5 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `city`;
CREATE TABLE `city` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ct_name` varchar(30) COLLATE latin1_general_ci NOT NULL,
  `ct_country` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_country_city` (`ct_country`),
  CONSTRAINT `fk_country_city` FOREIGN KEY (`ct_country`) REFERENCES `country` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;


DROP TABLE IF EXISTS `country`;
CREATE TABLE `country` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cnt_libelle` varchar(45) DEFAULT NULL,
  `cnt_iso2` varchar(2) DEFAULT NULL,
  `cnt_iso3` varchar(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `country` (`id`, `cnt_libelle`, `cnt_iso2`, `cnt_iso3`) VALUES
(1,	'Afghanistan',	'1',	''),
(2,	'Albanie',	'1',	''),
(3,	'Antarctique',	'1',	''),
(4,	'Algérie',	'1',	''),
(5,	'Samoa Américaines',	'1',	''),
(6,	'Andorre',	'1',	''),
(7,	'Angola',	'1',	''),
(8,	'Antigua-et-Barbuda',	'1',	''),
(9,	'Azerbaïdjan',	'1',	''),
(10,	'Argentine',	'1',	''),
(11,	'Australie',	'1',	''),
(12,	'Autriche',	'1',	''),
(13,	'Bahamas',	'1',	''),
(14,	'Bahreïn',	'1',	''),
(15,	'Bangladesh',	'1',	''),
(16,	'Arménie',	'1',	''),
(17,	'Barbade',	'1',	''),
(18,	'Belgique',	'1',	''),
(19,	'Bermudes',	'1',	''),
(20,	'Bhoutan',	'1',	''),
(21,	'Bolivie',	'1',	''),
(22,	'Bosnie-Herzégovine',	'1',	''),
(23,	'Botswana',	'1',	''),
(24,	'Île Bouvet',	'1',	''),
(25,	'Brésil',	'1',	''),
(26,	'Belize',	'1',	''),
(27,	'Territoire Britannique de l\'Océan Indien',	'1',	''),
(28,	'Îles Salomon',	'1',	''),
(29,	'Îles Vierges Britanniques',	'1',	''),
(30,	'Brunéi Darussalam',	'1',	''),
(31,	'Bulgarie',	'1',	''),
(32,	'Myanmar',	'1',	''),
(33,	'Burundi',	'1',	''),
(34,	'Bélarus',	'1',	''),
(35,	'Cambodge',	'1',	''),
(36,	'Cameroun',	'1',	''),
(37,	'Canada',	'1',	''),
(38,	'Cap-vert',	'1',	''),
(39,	'Îles Caïmanes',	'1',	''),
(40,	'République Centrafricaine',	'1',	''),
(41,	'Sri Lanka',	'1',	''),
(42,	'Tchad',	'1',	''),
(43,	'Chili',	'1',	''),
(44,	'Chine',	'1',	''),
(45,	'Taïwan',	'1',	''),
(46,	'Île Christmas',	'1',	''),
(47,	'Îles Cocos (Keeling)',	'1',	''),
(48,	'Colombie',	'1',	''),
(49,	'Comores',	'1',	''),
(50,	'Mayotte',	'1',	''),
(51,	'République du Congo',	'1',	''),
(52,	'République Démocratique du Congo',	'1',	''),
(53,	'Îles Cook',	'1',	''),
(54,	'Costa Rica',	'1',	''),
(55,	'Croatie',	'1',	''),
(56,	'Cuba',	'1',	''),
(57,	'Chypre',	'1',	''),
(58,	'République Tchèque',	'1',	''),
(59,	'Bénin',	'1',	''),
(60,	'Danemark',	'1',	''),
(61,	'Dominique',	'1',	''),
(62,	'République Dominicaine',	'1',	''),
(63,	'Équateur',	'1',	''),
(64,	'El Salvador',	'1',	''),
(65,	'Guinée Équatoriale',	'1',	''),
(66,	'Éthiopie',	'1',	''),
(67,	'Érythrée',	'1',	''),
(68,	'Estonie',	'1',	''),
(69,	'Îles Féroé',	'1',	''),
(70,	'Îles (malvinas) Falkland',	'1',	''),
(71,	'Géorgie du Sud et les Îles Sandwich du Sud',	'1',	''),
(72,	'Fidji',	'1',	''),
(73,	'Finlande',	'1',	''),
(74,	'Îles Åland',	'1',	''),
(75,	'France',	'1',	''),
(76,	'Guyane Française',	'1',	''),
(77,	'Polynésie Française',	'1',	''),
(78,	'Terres Australes Françaises',	'1',	''),
(79,	'Djibouti',	'1',	''),
(80,	'Gabon',	'1',	''),
(81,	'Géorgie',	'1',	''),
(82,	'Gambie',	'1',	''),
(83,	'Territoire Palestinien Occupé',	'1',	''),
(84,	'Allemagne',	'1',	''),
(85,	'Ghana',	'1',	''),
(86,	'Gibraltar',	'1',	''),
(87,	'Kiribati',	'1',	''),
(88,	'Grèce',	'1',	''),
(89,	'Groenland',	'1',	''),
(90,	'Grenade',	'1',	''),
(91,	'Guadeloupe',	'1',	''),
(92,	'Guam',	'1',	''),
(93,	'Guatemala',	'1',	''),
(94,	'Guinée',	'1',	''),
(95,	'Guyana',	'1',	''),
(96,	'Haïti',	'1',	''),
(97,	'Îles Heard et Mcdonald',	'1',	''),
(98,	'Saint-Siège (état de la Cité du Vatican)',	'1',	''),
(99,	'Honduras',	'1',	''),
(100,	'Hong-Kong',	'1',	''),
(101,	'Hongrie',	'1',	''),
(102,	'Islande',	'1',	''),
(103,	'Inde',	'1',	''),
(104,	'Indonésie',	'1',	''),
(105,	'République Islamique d\'Iran',	'1',	''),
(106,	'Iraq',	'1',	''),
(107,	'Irlande',	'1',	''),
(108,	'Israël',	'1',	''),
(109,	'Italie',	'1',	''),
(110,	'Côte d\'Ivoire',	'1',	''),
(111,	'Jamaïque',	'1',	''),
(112,	'Japon',	'1',	''),
(113,	'Kazakhstan',	'1',	''),
(114,	'Jordanie',	'1',	''),
(115,	'Kenya',	'1',	''),
(116,	'République Populaire Démocratique de Corée',	'1',	''),
(117,	'République de Corée',	'1',	''),
(118,	'Koweït',	'1',	''),
(119,	'Kirghizistan',	'1',	''),
(120,	'République Démocratique Populaire Lao',	'1',	''),
(121,	'Liban',	'1',	''),
(122,	'Lesotho',	'1',	''),
(123,	'Lettonie',	'1',	''),
(124,	'Libéria',	'1',	''),
(125,	'Jamahiriya Arabe Libyenne',	'1',	''),
(126,	'Liechtenstein',	'1',	''),
(127,	'Lituanie',	'1',	''),
(128,	'Luxembourg',	'1',	''),
(129,	'Macao',	'1',	''),
(130,	'Madagascar',	'1',	''),
(131,	'Malawi',	'1',	''),
(132,	'Malaisie',	'1',	''),
(133,	'Maldives',	'1',	''),
(134,	'Mali',	'1',	''),
(135,	'Malte',	'1',	''),
(136,	'Martinique',	'1',	''),
(137,	'Mauritanie',	'1',	''),
(138,	'Maurice',	'1',	''),
(139,	'Mexique',	'1',	''),
(140,	'Monaco',	'1',	''),
(141,	'Mongolie',	'1',	''),
(142,	'République de Moldova',	'1',	''),
(143,	'Montserrat',	'1',	''),
(144,	'Maroc',	'1',	''),
(145,	'Mozambique',	'1',	''),
(146,	'Oman',	'1',	''),
(147,	'Namibie',	'1',	''),
(148,	'Nauru',	'1',	''),
(149,	'Népal',	'1',	''),
(150,	'Pays-Bas',	'1',	''),
(151,	'Antilles Néerlandaises',	'1',	''),
(152,	'Aruba',	'1',	''),
(153,	'Nouvelle-Calédonie',	'1',	''),
(154,	'Vanuatu',	'1',	''),
(155,	'Nouvelle-Zélande',	'1',	''),
(156,	'Nicaragua',	'1',	''),
(157,	'Niger',	'1',	''),
(158,	'Nigéria',	'1',	''),
(159,	'Niué',	'1',	''),
(160,	'Île Norfolk',	'1',	''),
(161,	'Norvège',	'1',	''),
(162,	'Îles Mariannes du Nord',	'1',	''),
(163,	'Îles Mineures Éloignées des États-Unis',	'1',	''),
(164,	'États Fédérés de Micronésie',	'1',	''),
(165,	'Îles Marshall',	'1',	''),
(166,	'Palaos',	'1',	''),
(167,	'Pakistan',	'1',	''),
(168,	'Panama',	'1',	''),
(169,	'Papouasie-Nouvelle-Guinée',	'1',	''),
(170,	'Paraguay',	'1',	''),
(171,	'Pérou',	'1',	''),
(172,	'Philippines',	'1',	''),
(173,	'Pitcairn',	'1',	''),
(174,	'Pologne',	'1',	''),
(175,	'Portugal',	'1',	''),
(176,	'Guinée-Bissau',	'1',	''),
(177,	'Timor-Leste',	'1',	''),
(178,	'Porto Rico',	'1',	''),
(179,	'Qatar',	'1',	''),
(180,	'Réunion',	'1',	''),
(181,	'Roumanie',	'1',	''),
(182,	'Fédération de Russie',	'1',	''),
(183,	'Rwanda',	'1',	''),
(184,	'Sainte-Hélène',	'1',	''),
(185,	'Saint-Kitts-et-Nevis',	'1',	''),
(186,	'Anguilla',	'1',	''),
(187,	'Sainte-Lucie',	'1',	''),
(188,	'Saint-Pierre-et-Miquelon',	'1',	''),
(189,	'Saint-Vincent-et-les Grenadines',	'1',	''),
(190,	'Saint-Marin',	'1',	''),
(191,	'Sao Tomé-et-Principe',	'1',	''),
(192,	'Arabie Saoudite',	'1',	''),
(193,	'Sénégal',	'1',	''),
(194,	'Seychelles',	'1',	''),
(195,	'Sierra Leone',	'1',	''),
(196,	'Singapour',	'1',	''),
(197,	'Slovaquie',	'1',	''),
(198,	'Viet Nam',	'1',	''),
(199,	'Slovénie',	'1',	''),
(200,	'Somalie',	'1',	''),
(201,	'Afrique du Sud',	'1',	''),
(202,	'Zimbabwe',	'1',	''),
(203,	'Espagne',	'1',	''),
(204,	'Sahara Occidental',	'1',	''),
(205,	'Soudan',	'1',	''),
(206,	'Suriname',	'1',	''),
(207,	'Svalbard etÎle Jan Mayen',	'1',	''),
(208,	'Swaziland',	'1',	''),
(209,	'Suède',	'1',	''),
(210,	'Suisse',	'1',	''),
(211,	'République Arabe Syrienne',	'1',	''),
(212,	'Tadjikistan',	'1',	''),
(213,	'Thaïlande',	'1',	''),
(214,	'Togo',	'1',	''),
(215,	'Tokelau',	'1',	''),
(216,	'Tonga',	'1',	''),
(217,	'Trinité-et-Tobago',	'1',	''),
(218,	'Émirats Arabes Unis',	'1',	''),
(219,	'Tunisie',	'1',	''),
(220,	'Turquie',	'1',	''),
(221,	'Turkménistan',	'1',	''),
(222,	'Îles Turks et Caïques',	'1',	''),
(223,	'Tuvalu',	'1',	''),
(224,	'Ouganda',	'1',	''),
(225,	'Ukraine',	'1',	''),
(226,	'L\'ex-République Yougoslave de Macédoine',	'1',	''),
(227,	'Égypte',	'1',	''),
(228,	'Royaume-Uni',	'1',	''),
(229,	'Île de Man',	'1',	''),
(230,	'République-Unie de Tanzanie',	'1',	''),
(231,	'États-Unis',	'1',	''),
(232,	'Îles Vierges des États-Unis',	'1',	''),
(233,	'Burkina Faso',	'1',	''),
(234,	'Uruguay',	'1',	''),
(235,	'Ouzbékistan',	'1',	''),
(236,	'Venezuela',	'1',	''),
(237,	'Wallis et Futuna',	'1',	''),
(238,	'Samoa',	'1',	''),
(239,	'Yémen',	'1',	''),
(240,	'Serbie-et-Monténégro',	'1',	''),
(241,	'Zambie',	'1',	'');

DROP TABLE IF EXISTS `image`;
CREATE TABLE `image` (
  `id` int(11) NOT NULL,
  `img_title` varchar(45) DEFAULT NULL,
  `img_path` varchar(50) DEFAULT NULL,
  `img_parent` int(11) NOT NULL,
  `img_status` char(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_produit` (`img_parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `product`;
CREATE TABLE `product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pro_name` varchar(45) DEFAULT NULL,
  `pro_description` text,
  `pro_added_at` datetime DEFAULT NULL,
  `pro_category` int(11) NOT NULL,
  `pro_user` int(11) NOT NULL,
  `pro_status` char(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_pro_category` (`pro_category`),
  KEY `idx_pro_user` (`pro_user`),
  CONSTRAINT `fk_product_category` FOREIGN KEY (`pro_category`) REFERENCES `product_category` (`id`),
  CONSTRAINT `fk_product_user` FOREIGN KEY (`pro_user`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `product` (`id`, `pro_name`, `pro_description`, `pro_added_at`, `pro_category`, `pro_user`, `pro_status`) VALUES
(1,	'Ordinateur',	'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo',	NULL,	1,	1,	'1');

DROP TABLE IF EXISTS `product_category`;
CREATE TABLE `product_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pc_name` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `pc_description` varchar(100) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `product_category` (`id`, `pc_name`, `pc_description`) VALUES
(1,	'Electronique',	'Electronique'),
(2,	'Habillement',	'Habillement');

DROP TABLE IF EXISTS `publicite`;
CREATE TABLE `publicite` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(45) DEFAULT NULL,
  `description` varchar(45) DEFAULT NULL,
  `begin_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `fk_user` int(11) NOT NULL,
  `statut` char(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_user` (`fk_user`),
  CONSTRAINT `publicite_ibfk_1` FOREIGN KEY (`fk_user`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `service`;
CREATE TABLE `service` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sv_name` varchar(45) DEFAULT NULL,
  `sv_description` text,
  `sv_category` int(11) NOT NULL,
  `sv_user` int(11) NOT NULL,
  `sv_status` char(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `fk_user` (`sv_user`),
  KEY `idx_category` (`sv_category`),
  CONSTRAINT `fk_service_category` FOREIGN KEY (`sv_category`) REFERENCES `service_category` (`id`),
  CONSTRAINT `service_ibfk_1` FOREIGN KEY (`sv_user`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `service` (`id`, `sv_name`, `sv_description`, `sv_category`, `sv_user`, `sv_status`) VALUES
(1,	'Developpement Web',	'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo',	1,	1,	'1'),
(2,	'Developpement Mobile',	'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo',	1,	1,	'1'),
(3,	'Hopital Dallal Diam',	'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo',	2,	2,	'1');

DROP TABLE IF EXISTS `service_category`;
CREATE TABLE `service_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sc_name` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `sc_description` varchar(100) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `service_category` (`id`, `sc_name`, `sc_description`) VALUES
(1,	'Informatique',	'Service informatique'),
(2,	'Santé',	'Service Sanitaire');

DROP TABLE IF EXISTS `structure`;
CREATE TABLE `structure` (
  `id` int(11) NOT NULL,
  `str_name` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `str_enseigne` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `str_logo` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `str_phone` varchar(30) COLLATE latin1_general_ci NOT NULL,
  `str_email` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `str_web_site` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `str_lat` int(11) NOT NULL,
  `str_lon` int(11) NOT NULL,
  `str_description` text COLLATE latin1_general_ci NOT NULL,
  `str_type` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_structure_type` (`str_type`),
  CONSTRAINT `fk_structure_type` FOREIGN KEY (`str_type`) REFERENCES `structure_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci ROW_FORMAT=COMPACT;


DROP TABLE IF EXISTS `structure_type`;
CREATE TABLE `structure_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `st_name` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `st_description` int(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;


DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(30) DEFAULT NULL,
  `phone` varchar(45) DEFAULT NULL,
  `email` varchar(225) DEFAULT NULL,
  `address` text,
  `image` varchar(45) DEFAULT NULL,
  `fk_domaine` int(11) NOT NULL,
  `statut` char(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user_domaine` (`fk_domaine`),
  CONSTRAINT `fk_domaine_user` FOREIGN KEY (`fk_domaine`) REFERENCES `user_domaine` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `user` (`id`, `first_name`, `last_name`, `phone`, `email`, `address`, `image`, `fk_domaine`, `statut`) VALUES
(1,	'Ibrahima',	'Thiame',	'776025135',	'ib.thiamass@gmail.com',	'Hersent, THIES',	NULL,	1,	'O'),
(2,	'Amadou',	'NDIAYE',	'779258379',	'douNdiaye@gmail.com',	'Parcelle Unité 26',	NULL,	1,	'1');

DROP TABLE IF EXISTS `user_credential`;
CREATE TABLE `user_credential` (
  `id` int(11) NOT NULL,
  `crd_login` varchar(45) DEFAULT NULL,
  `crd_password` varchar(45) DEFAULT NULL,
  `crd_salt` varchar(100) NOT NULL,
  `crd_create_at` datetime DEFAULT NULL,
  `crd_user` int(11) NOT NULL,
  `crd_status` char(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_user` (`crd_user`),
  CONSTRAINT `fk_user` FOREIGN KEY (`crd_user`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `user_domaine`;
CREATE TABLE `user_domaine` (
  `id` int(11) NOT NULL,
  `dm_name` varchar(45) DEFAULT NULL,
  `dm_description` longtext,
  `dm_status` char(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `user_domaine` (`id`, `dm_name`, `dm_description`, `dm_status`) VALUES
(1,	'Developpeur Fullstack',	'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo',	'1');

DROP TABLE IF EXISTS `user_structure`;
CREATE TABLE `user_structure` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fk_user` int(11) NOT NULL,
  `fk_structure` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user` (`fk_user`),
  KEY `idx_structure` (`fk_structure`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;


-- 2020-01-26 00:10:28
